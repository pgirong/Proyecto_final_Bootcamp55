package com.nttdata.Proyecto01Cuentas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto01CuentasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto01CuentasApplication.class, args);
	}

}
