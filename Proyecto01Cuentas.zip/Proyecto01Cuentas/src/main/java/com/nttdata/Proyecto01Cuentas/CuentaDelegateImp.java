package com.nttdata.Proyecto01Cuentas;

import com.nttdata.Proyecto01Cuentas.business.CuentaService;
import com.nttdata.Proyecto01Cuentas.api.CuentaApiDelegate;
import com.nttdata.Proyecto01Cuentas.model.CuentaResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CuentaDelegateImp implements CuentaApiDelegate {

    @Autowired
    CuentaService cuentaService;

    @Override
    public ResponseEntity<CuentaResponse> crearCuenta(CuentaResponse cuentaResponse) {
        return ResponseEntity.ok(cuentaService.crearCuenta(cuentaResponse));
    }

    @Override
    public ResponseEntity<List<CuentaResponse>> listarCuenta() {
        return ResponseEntity.ok(cuentaService.listarCuenta());
    }
}
