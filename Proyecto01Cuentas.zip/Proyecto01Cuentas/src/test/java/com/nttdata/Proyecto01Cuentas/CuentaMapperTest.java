package com.nttdata.Proyecto01Cuentas;

import com.nttdata.Proyecto01Cuentas.business.CuentaMapper;
import com.nttdata.Proyecto01Cuentas.model.CuentaResponse;
import com.nttdata.Proyecto01Cuentas.model.entity.Cuenta;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CuentaMapperTest {

    private CuentaMapper mapper = new CuentaMapper();

    @Test
    @DisplayName("Test Ingreso Informacion")
    void testGetCuentaEntity(){
        CuentaResponse request = new CuentaResponse();
        request.setNumero("2255998775365000");
        request.setTipo("Ahorro");

        Cuenta result = mapper.getCuentaEntity(request);

        assertNotNull(result);
        assertEquals(request.getNumero(),result.getNumero());
        assertEquals(request.getTipo(),result.getTipo());

    }

    @Test
    @DisplayName("Test Respuesta")
    void testCuentaResponse(){
        Cuenta response = new Cuenta();
        response.setNumero("2255998775365555");
        response.setTipo("Ahorro");

        CuentaResponse result = mapper.getCuentaResponse(response);
    }


}
