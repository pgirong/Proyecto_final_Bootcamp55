package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.CuentaRequest;
import com.nttdata.transaccion.model.CuentaResponse;

import java.util.List;

public interface TransaccionService {

    public CuentaResponse depositoCuenta(CuentaRequest cuentaRequest);
    public CuentaResponse retiroCuenta(CuentaRequest cuentaRequest);
    public CuentaResponse registroCuenta(CuentaRequest cuentaRequest);
    public List<CuentaResponse> listarCuenta();
}
