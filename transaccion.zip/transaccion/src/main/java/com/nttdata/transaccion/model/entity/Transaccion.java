package com.nttdata.transaccion.model.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Document(collection = "tablapg")
public class Transaccion {
    @Id
    private String idtransaccion;
    private String tipo;
    private String monto;
    private String fecha;
    private String tipocuentas;
    private String cuentaOrigen;
    private String cuentaDestino;
}
