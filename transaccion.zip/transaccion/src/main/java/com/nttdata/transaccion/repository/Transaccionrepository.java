package com.nttdata.transaccion.repository;

import com.nttdata.transaccion.model.entity.Transaccion;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface Transaccionrepository extends MongoRepository<Transaccion,String> {


}
