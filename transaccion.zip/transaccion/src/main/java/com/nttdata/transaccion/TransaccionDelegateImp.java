package com.nttdata.transaccion;


import com.nttdata.transaccion.api.ApiApiDelegate;
import com.nttdata.transaccion.business.TransaccionService;
import com.nttdata.transaccion.model.CuentaRequest;
import com.nttdata.transaccion.model.CuentaResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransaccionDelegateImp implements ApiApiDelegate {

     @Autowired
    TransaccionService transaccionService;

    @Override
    public ResponseEntity<CuentaResponse> depositoCuenta(CuentaRequest cuentaRequest) {
        validateDepositoyRetiro(cuentaRequest);
        cuentaRequest.setTipo("Deposito");
        return ResponseEntity.ok(transaccionService.depositoCuenta(cuentaRequest));
    }

    @Override
    public ResponseEntity<CuentaResponse> registroCuenta(CuentaRequest cuentaRequest) {
        validatetrx(cuentaRequest);
        cuentaRequest.setTipo("Transferencia");
        return ResponseEntity.ok(transaccionService.registroCuenta(cuentaRequest));
    }

    @Override
    public ResponseEntity<CuentaResponse> retiroCuenta(CuentaRequest cuentaRequest) {
        validateDepositoyRetiro(cuentaRequest);
        cuentaRequest.setTipo("Retiro");
        return ResponseEntity.ok(transaccionService.retiroCuenta(cuentaRequest));
    }

    @Override
    public ResponseEntity<List<CuentaResponse>> listarCuenta() {
        return ResponseEntity.ok(transaccionService.listarCuenta());
    }


    @SneakyThrows
    private void validateDepositoyRetiro(CuentaRequest cuentaRequest) {
        if (cuentaRequest.getCuentaDestino() != null && !cuentaRequest.getCuentaDestino().isEmpty()) {
            throw new BadRequestException("La cuenta destino no es requerida para esta operacion");
        }
        if (cuentaRequest.getCuentaOrigen() == null || cuentaRequest.getCuentaOrigen().isEmpty()) {
            throw new BadRequestException("La cuenta origen es obligatoria");
        }
    }


    @SneakyThrows
    private void validatetrx(CuentaRequest cuentaRequest) {
        if (cuentaRequest.getCuentaOrigen() != null && !cuentaRequest.getCuentaOrigen().isEmpty()) {
            throw new BadRequestException("La cuenta origen no es requerida para esta operacion");
        }
        if (cuentaRequest.getCuentaDestino() == null || cuentaRequest.getCuentaDestino().isEmpty()) {
            throw new BadRequestException("La cuenta destino es obligatoria");
        }
    }





}








