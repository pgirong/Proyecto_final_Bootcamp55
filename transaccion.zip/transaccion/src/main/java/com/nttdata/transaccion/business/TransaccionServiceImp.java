package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.CuentaRequest;
import com.nttdata.transaccion.model.CuentaResponse;


import com.nttdata.transaccion.repository.Transaccionrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransaccionServiceImp implements TransaccionService{

    @Autowired
    Transaccionrepository transaccionrepository;

    @Autowired
    TransaccionMapper transaccionMapper;

    @Override
    public CuentaResponse depositoCuenta(CuentaRequest cuentaRequest){

        return transaccionMapper.getTransaccionResponse(transaccionrepository
                .save(transaccionMapper.getTransaccionRequest(cuentaRequest)));
    }

    public CuentaResponse retiroCuenta(CuentaRequest cuentaRequest){

         return transaccionMapper.getTransaccionResponse(transaccionrepository
                 .save(transaccionMapper.getTransaccionRequest(cuentaRequest)));
    }

    public CuentaResponse registroCuenta(CuentaRequest cuentaRequest){

        return transaccionMapper.getTransaccionResponse(transaccionrepository
                .save(transaccionMapper.getTransaccionRequest(cuentaRequest)));
    }

    @Override
    public List<CuentaResponse> listarCuenta() {
        return transaccionrepository.findAll().stream()
                .map(l->transaccionMapper.getTransaccionResponse(l))
                .collect(Collectors.toList());

    }
}

