package com.nttdata.transaccion.business;

import com.nttdata.transaccion.model.CuentaRequest;
import com.nttdata.transaccion.model.CuentaResponse;
import com.nttdata.transaccion.model.entity.Transaccion;
import org.springframework.stereotype.Component;

@Component
public class TransaccionMapper {

     public Transaccion getTransaccionRequest(CuentaRequest request){
          Transaccion entity = new Transaccion();
          entity.setTipo(request.getTipo());
          entity.setMonto(request.getMonto());
          entity.setFecha(request.getFecha());
          entity.setTipocuentas(request.getTipocuentas());
          entity.setCuentaOrigen(request.getCuentaOrigen());
          entity.setCuentaDestino(request.getCuentaDestino());
          return entity;
     }

     public CuentaResponse getTransaccionResponse(Transaccion entity){
          CuentaResponse response = new CuentaResponse();
          response.setFecha(entity.getFecha());
          response.setTipocuentas(entity.getTipocuentas());
          response.setMonto(entity.getMonto());
          response.setTipo(entity.getTipo());
          response.setCuentaOrigen(entity.getCuentaOrigen());
          response.setCuentaDestino(entity.getCuentaDestino());
          return response;

     }

}






