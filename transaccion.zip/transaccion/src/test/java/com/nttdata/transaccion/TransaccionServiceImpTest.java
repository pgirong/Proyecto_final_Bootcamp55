package com.nttdata.transaccion;

public class TransaccionServiceImpTest {
}
