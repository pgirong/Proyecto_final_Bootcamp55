package com.nttdata.transaccion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransaccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
