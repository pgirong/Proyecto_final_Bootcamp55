package com.nttdata.transaccion;

import com.nttdata.transaccion.business.TransaccionService;
import com.nttdata.transaccion.model.CuentaRequest;
import com.nttdata.transaccion.model.CuentaResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;

public class TransaccionDelegateImpTest {

    @Mock
    private TransaccionService transaccionService;

    @InjectMocks
    private TransaccionDelegateImp transaccionDelegateImp;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Validacion Deposito")
    void testDepositarValidacion(){
        CuentaRequest request = new CuentaRequest();
        request.setMonto("600");
        request.setCuentaOrigen("00158974866");

        CuentaResponse responseMock = new CuentaResponse();
        responseMock.setMonto(request.getMonto());
        responseMock.setCuentaOrigen(request.getCuentaOrigen());
        responseMock.setTipo("Deposito");

        when(transaccionService.depositoCuenta(any())).thenReturn(responseMock);

        ResponseEntity<CuentaResponse> response = transaccionDelegateImp.depositoCuenta(request);

        assertNotNull(response);
        assertEquals(200,response.getStatusCodeValue());
        assertEquals(responseMock,response.getBody());
        assertEquals("Deposito",response.getBody().getTipo());
        verify(transaccionService).depositoCuenta(request);
    }

    @Test
    @DisplayName("Validacion Retiro")
    void testRetirarValidacion(){
        CuentaRequest request = new CuentaRequest();
        request.setMonto("400");
        request.setCuentaOrigen("00158974866");

        CuentaResponse responseMock = new CuentaResponse();
        responseMock.setMonto(request.getMonto());
        responseMock.setCuentaOrigen(request.getCuentaOrigen());
        responseMock.setTipo("Retiro");

        when(transaccionService.retiroCuenta(any())).thenReturn(responseMock);

        ResponseEntity<CuentaResponse> response = transaccionDelegateImp.retiroCuenta(request);

        assertNotNull(response);
        assertEquals(200,response.getStatusCodeValue());
        assertEquals(responseMock,response.getBody());
        assertEquals("Retiro",response.getBody().getTipo());
        verify(transaccionService).retiroCuenta(request);

    }

    @Test
    @DisplayName("Validacion Transferencia")
    void testtransferenciaValidacion(){
        CuentaRequest request = new CuentaRequest();
        request.setMonto("950");

        request.setCuentaDestino("123987225");

        CuentaResponse responseMock = new CuentaResponse();
        responseMock.setMonto(request.getMonto());

        responseMock.setCuentaDestino(request.getCuentaDestino());
        responseMock.setTipo("Transferencia");

        when(transaccionService.registroCuenta(any())).thenReturn(responseMock);

        ResponseEntity<CuentaResponse> response = transaccionDelegateImp.registroCuenta(request);

        assertNotNull(response);
        assertEquals(200,response.getStatusCodeValue());
        assertEquals(responseMock,response.getBody());
        assertEquals("Transferencia",response.getBody().getTipo());
        verify(transaccionService).registroCuenta(request);
    }


     @Test
    @DisplayName("Validacion Historial")
    void testHistorialValidacion(){
        List<CuentaResponse> transacciones = Arrays.asList(new CuentaResponse(), new CuentaResponse());
         when(transaccionService.listarCuenta()).thenReturn(transacciones);

         ResponseEntity<List<CuentaResponse>> response = transaccionDelegateImp.listarCuenta();

         assertNotNull(response);
         assertEquals(200, response.getStatusCodeValue());
         assertEquals(2, response.getBody().size());
         verify(transaccionService).listarCuenta();
     }
}
