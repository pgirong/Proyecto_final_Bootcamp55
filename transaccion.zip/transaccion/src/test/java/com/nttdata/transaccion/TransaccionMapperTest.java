package com.nttdata.transaccion;

import com.nttdata.transaccion.business.TransaccionMapper;
import com.nttdata.transaccion.model.CuentaRequest;
import com.nttdata.transaccion.model.CuentaResponse;
import com.nttdata.transaccion.model.entity.Transaccion;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;

public class TransaccionMapperTest {

    private TransaccionMapper mapper = new TransaccionMapper();

    @Test
    @DisplayName("Test Ingreso Informacion")
    void testGetTransaccionEntity(){
        CuentaRequest request = new CuentaRequest();
        request.setTipo("Retiro");
        request.setMonto("300");
        request.setFecha("10-10-2024");
        request.setTipocuentas("ahorro");
        request.setCuentaOrigen("44556678");
        request.setCuentaDestino("87654321");


        Transaccion result = mapper.getTransaccionRequest(request);

        assertNotNull(result);
        assertEquals(request.getTipo(),result.getTipo());
        assertEquals(request.getMonto(),result.getMonto());
        assertEquals(request.getFecha(),result.getFecha());
        assertEquals(request.getTipocuentas(),result.getTipocuentas());
        assertEquals(request.getCuentaOrigen(),result.getCuentaOrigen());
        assertEquals(request.getCuentaDestino(),result.getCuentaDestino());

    }

    @Test
    @DisplayName("Test Respuesta")
    void testTransaccionResponse(){
        Transaccion response = new Transaccion();
        response.setTipo("Retiro");
        response.setMonto("300");
        response.setFecha("10-10-2024");
        response.setTipocuentas("ahorro");
        response.setCuentaOrigen("44556678");
        response.setCuentaDestino("87654321");

        CuentaResponse result = mapper.getTransaccionResponse(response);

    }



}
