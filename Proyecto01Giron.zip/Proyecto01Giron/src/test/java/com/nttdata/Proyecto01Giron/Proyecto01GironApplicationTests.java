package com.nttdata.Proyecto01Giron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto01GironApplicationTests {

	@Test
	void contextLoads() {
	}

}
