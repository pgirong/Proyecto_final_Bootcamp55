package com.nttdata.Proyecto01Giron;

import com.nttdata.Proyecto01Giron.business.ClienteService;
import com.nttdata.Proyecto01Giron.model.entity.Cliente;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class ClienteDelegateImpTest {

@Mock
    private ClienteService clienteService;

@InjectMocks
    private ClienteDelegateImp clienteDelegateImp;

@BeforeEach
    void SetUp(){
    MockitoAnnotations.openMocks(this);
}

@Test
    @DisplayName("Validacion Crear")
    void testCrearValidacion(){
    Cliente request = new Cliente();
    request.setNombre("Juan");
    request.setApellido("Perez");
    request.setDni("22558877");
    request.setEmail("juan.perez@gmail.com");

    com.nttdata.Proyecto01Giron.model.Cliente responseMock = new com.nttdata.Proyecto01Giron.model.Cliente();
    responseMock.setNombre(request.getNombre());
    responseMock.setApellido(request.getApellido());
    responseMock.setDni(request.getDni());
    responseMock.setEmail(request.getEmail());

    when(clienteService.crearCliente(any())).thenReturn(responseMock);


}
}
