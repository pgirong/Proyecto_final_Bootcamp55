package com.nttdata.Proyecto01Giron;

import com.nttdata.Proyecto01Giron.business.ClienteMapper;
import com.nttdata.Proyecto01Giron.model.entity.Cliente;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ClienteMapperTest {

    private ClienteMapper mapper = new ClienteMapper();

    @Test
    @DisplayName("Test Ingreso Informacion")
    void testGetClienteEntity(){
        com.nttdata.Proyecto01Giron.model.Cliente request = new com.nttdata.Proyecto01Giron.model.Cliente();
        request.setNombre("Juan");
        request.setApellido("Perez");
        request.setDni("87654321");
        request.setEmail("juan.perez@gmail.com");

        Cliente result = mapper.getClienteEntity(request);

        assertNotNull(result);
        assertEquals(request.getNombre(),result.getNombre());
        assertEquals(request.getApellido(),result.getApellido());
        assertEquals(request.getDni(),result.getDni());
        assertEquals(request.getEmail(),result.getEmail());

    }

    @Test
    @DisplayName("Test Respuesta")
    void testClienteResponse(){
        Cliente response = new Cliente();
        response.setNombre("Juan");
        response.setApellido("Perez");
        response.setDni("33445566");
        response.setEmail("juan.perez@hotmail.com");

        com.nttdata.Proyecto01Giron.model.Cliente result = mapper.getClienteResponse(response);


    }
}
