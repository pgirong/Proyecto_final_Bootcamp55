package com.nttdata.Proyecto01Giron.business;

import com.nttdata.Proyecto01Giron.model.Cliente;
import com.nttdata.Proyecto01Giron.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClienteServiceImp implements ClienteService{

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    ClienteMapper clienteMapper;


    @Override
    public List<Cliente> listCliente() {
        return clienteRepository.findAll().stream()
                .map(m-> clienteMapper.getClienteResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public Cliente crearCliente(Cliente clienteRequest){
        return clienteMapper
                .getClienteResponse(clienteRepository.
                        save(clienteMapper.getClienteEntity(clienteRequest)));
    }
}




