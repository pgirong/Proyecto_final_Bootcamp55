package com.nttdata.Proyecto01Giron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto01GironApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto01GironApplication.class, args);
	}

}
