package com.nttdata.Proyecto01Giron;

import com.nttdata.Proyecto01Giron.api.ClienteApiDelegate;
import com.nttdata.Proyecto01Giron.business.ClienteService;
import com.nttdata.Proyecto01Giron.model.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ClienteDelegateImp implements ClienteApiDelegate {

    @Autowired
    ClienteService clienteService;


    @Override
    public ResponseEntity<List<Cliente>> listarCliente() {
        return ResponseEntity.ok(clienteService.listCliente());
    }

    @Override
    public ResponseEntity<Cliente> crearCliente(Cliente cliente) {
        return ResponseEntity.ok(clienteService.crearCliente(cliente));
    }
}
