package com.nttdata.Proyecto01Giron.business;

import com.nttdata.Proyecto01Giron.model.Cliente;

import java.util.List;

public interface ClienteService {
    public List<Cliente> listCliente();
    public Cliente crearCliente(Cliente clienteRequest);

}
